import os
import requests
import yt_dlp
from mutagen.id3 import ID3, APIC, error
from mutagen.mp3 import MP3


print("       ▄█   ▄█▄    ▄████████ ███▄▄▄▄   ███▄▄▄▄      ▄████████        ▄▄▄▄███▄▄▄▄   ███    █▄     ▄████████  ▄█   ▄████████          ███      ▄██████▄   ▄██████▄   ▄█  ")
print("      ███ ▄███▀   ███    ███ ███▀▀▀██▄ ███▀▀▀██▄   ███    ███      ▄██▀▀▀███▀▀▀██▄ ███    ███   ███    ███ ███  ███    ███      ▀█████████▄ ███    ███ ███    ███ ███  ")
print("      ███▐██▀     ███    ███ ███   ███ ███   ███   ███    █▀       ███   ███   ███ ███    ███   ███    █▀  ███▌ ███    █▀          ▀███▀▀██ ███    ███ ███    ███ ███  ")
print("     ▄█████▀      ███    ███ ███   ███ ███   ███   ███             ███   ███   ███ ███    ███   ███        ███▌ ███                 ███   ▀ ███    ███ ███    ███ ███ ")
print("    ▀▀█████▄    ▀███████████ ███   ███ ███   ███ ▀███████████      ███   ███   ███ ███    ███ ▀███████████ ███▌ ███                 ███     ███    ███ ███    ███ ███  ")
print("      ███▐██▄     ███    ███ ███   ███ ███   ███          ███      ███   ███   ███ ███    ███          ███ ███  ███    █▄           ███     ███    ███ ███    ███ ███   ")
print("      ███ ▀███▄   ███    ███ ███   ███ ███   ███    ▄█    ███      ███   ███   ███ ███    ███    ▄█    ███ ███  ███    ███          ███     ███    ███ ███    ███ ███▌    ▄")
print("      ███   ▀█▀   ███    █▀   ▀█   █▀   ▀█   █▀   ▄████████▀        ▀█   ███   █▀  ████████▀   ▄████████▀  █▀   ████████▀          ▄████▀    ▀██████▀   ▀██████▀  █████▄▄██")
print("      ▀                                                                                                                                                           ▀        ")
print("")
print("")
print("")



def download_thumbnail(video_id):
    """Download the YouTube video thumbnail"""
    thumbnail_url = f"https://img.youtube.com/vi/{video_id}/maxresdefault.jpg"
    response = requests.get(thumbnail_url)
    if response.status_code == 200:
        return response.content
    else:
        print(f"Failed to download thumbnail for video ID: {video_id}")
        return None

def embed_thumbnail(mp3_file, thumbnail_data):
    """Embed the thumbnail into the MP3 file"""
    audio = MP3(mp3_file, ID3=ID3)
    try:
        audio.add_tags()
    except error:
        pass

    audio.tags.add(
        APIC(
            encoding=3,  # 3 is for utf-8
            mime='image/jpeg',  # Thumbnail type
            type=3,  # 3 is for the album art
            desc='Cover',
            data=thumbnail_data  # Thumbnail image bytes
        )
    )
    audio.save()

def download_playlist_songs():
    playlist_url = input("Enter the playlist URL: ")

    # Define folder
    folder_name = "songs"
    if not os.path.exists(folder_name):
        os.makedirs(folder_name)

    print(f"Downloading playlist into folder: {folder_name}")

    # yt-dlp options
    ydl_opts = {
        'format': 'bestaudio/best',
        'postprocessors': [{
            'key': 'FFmpegExtractAudio',
            'preferredcodec': 'mp3',
            'preferredquality': '192',
        }],
        'outtmpl': os.path.join(folder_name, '%(title)s.%(ext)s'),
        'writethumbnail': True,  # This will download the thumbnail
    }

    # Download playlist
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        info_dict = ydl.extract_info(playlist_url, download=True)

        # Iterate over each video in the playlist and embed thumbnail
        for video in info_dict['entries']:
            if video is None:
                continue

            # Get the downloaded MP3 path and video ID
            video_id = video.get('id')
            mp3_file = os.path.join(folder_name, f"{video.get('title')}.mp3")

            # Download the thumbnail
            thumbnail_data = download_thumbnail(video_id)
            if thumbnail_data:
                # Embed thumbnail into MP3
                embed_thumbnail(mp3_file, thumbnail_data)
                print(f"Thumbnail embedded into: {mp3_file}")
            else:
                print(f"Failed to download thumbnail for {video.get('title')}")

    print("Download complete!")

if __name__ == "__main__":
    download_playlist_songs()